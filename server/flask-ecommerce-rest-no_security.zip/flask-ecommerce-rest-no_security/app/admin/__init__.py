from flask import Blueprint
from app.models import (
    db,
    StoreRegistration,
    StoreRequestStatus,
    User
)

admin=Blueprint('admin', __name__)

from . import routes