from . import (
    admin as admin_bp,
    db,
    StoreRegistration,
    StoreRequestStatus,
    User
)
from flask import (
    jsonify,
    abort
)
from app.decorators import (
    admin_required
)
from flask_jwt_extended import (
    jwt_required
)
from sqlalchemy import select

@admin_bp.get('/get-users')
@jwt_required()
@admin_required()
def getUsers():
    users = db.session.execute(select(User)).scalars().all()
    usersJSON=[]
    for user in users:
        usersJSON.append(user.to_json())

    try:
        return jsonify(users=usersJSON), 200
    except:
        db.session.rollback()
        return jsonify(msg='Error occurred!'), 500

@admin_bp.get('/get-store-registrations')
@jwt_required()
@admin_required()
def getStoreRegistrations():
    storeRegistrations = db.session.execute(select(StoreRegistration).where(StoreRegistration.request_status==StoreRequestStatus.PENDING.name)).scalars().all()
    storeRegistrationsJSON = []
    for registration in storeRegistrations:
        storeRegistrationsJSON.append(registration.to_json())

    try:
        return jsonify(StoreRegistrations=storeRegistrationsJSON), 200
    except:
        db.session.rollback()
        return jsonify(msg='Error occurred!'), 500
    
@admin_bp.post('/accept-store-registration/<int:registration_id>')
@jwt_required()
@admin_required()
def acceptStoreRegistrationRequest(registration_id):
    storeRegistration = db.session.execute(select(StoreRegistration).where(StoreRegistration.id==registration_id)).scalar_one_or_none()

    try:
        if storeRegistration.request_status.name==StoreRequestStatus.REJECTED.name:
            return jsonify(msg='Request already rejected!')
        elif storeRegistration.request_status.name==StoreRequestStatus.ACCEPTED.name:
            return jsonify(msg='Request already accepted!')

        storeRegistration.acceptStoreRegistration()
        db.session.commit()

        return jsonify(msg='Store registration accepted!'), 200
    except:
        db.session.rollback()
        return jsonify(msg='Error occurred!'), 500
    
@admin_bp.post('/reject-store-registration/<int:registration_id>')
@jwt_required()
@admin_required()
def rejectStoreRegistrationRequest(registration_id):
    storeRegistration = db.session.execute(select(StoreRegistration).where(StoreRegistration.id==registration_id)).scalar_one_or_none()

    try:
        if storeRegistration.request_status.name==StoreRequestStatus.REJECTED.name:
            return jsonify(msg='Request already rejected!')
        elif storeRegistration.request_status.name==StoreRequestStatus.ACCEPTED.name:
            return jsonify(msg='Request already accepted!')

        storeRegistration.rejectStoreRegistration()
        db.session.commit()
        
        return jsonify(msg='Store registration accepted!'), 200
    except:
        db.session.rollback()
        return jsonify(msg='Error occurred!'), 500