from datetime import datetime, timezone, timedelta

from . import (
    auth as auth_bp,
    db,
    User,
    RoleTypes,
    Role,
    UserRole,
    jwt
)
from flask import (
    jsonify,
    abort,
    request
)
from flask_jwt_extended import (
    create_access_token,
    jwt_required,
    get_jwt,
    get_jwt_identity,
    unset_jwt_cookies,
    set_access_cookies,
    current_user
)
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

@auth_bp.after_request
def refresh_expiring_jwts(response):
    try:
        exp_timestamp = get_jwt()["exp"]
        now = datetime.now(timezone.utc)
        target_timestamp = datetime.timestamp(now + timedelta(minutes=30))
        if target_timestamp > exp_timestamp:
            access_token = create_access_token(identity=get_jwt_identity())
            set_access_cookies(response, access_token)
        return response
    except (RuntimeError, KeyError):
        # Case where there is not a valid JWT. Just return the original response
        return response
    
@jwt.user_identity_loader
def user_identity_lookup(user):
    founduser = db.session.execute(select(User).where(User.username==user)).scalar_one_or_none()
    return str(founduser.id)

@jwt.user_lookup_loader
def user_lookup_callback(_jwt_header, jwt_data):
    identity = jwt_data["sub"]
    return db.session.execute(select(User).where(User.id==identity)).scalar_one_or_none()

@auth_bp.post('/login')
def login():
    if not request.is_json:
        abort(400)

    data = request.get_json()

    username=data['username']
    password=data['password']
    
    user=db.session.execute(select(User).where(User.username==username)).scalar_one_or_none()

    if username=="" or password=="":
        return jsonify(msg="Please input your credentials!"), 401
    if user is None:
        return jsonify(msg="User does not exist!"), 401
    if user.check_password(password)==False:
        return jsonify(msg="Incorrect password!"), 401
    
    user_roles=db.session.execute(
        select(UserRole.role_id).join(User).where(UserRole.user_id==user.id)
    ).scalars().all()

    claims={
        'is_buyer': True,
        'is_seller': False,
        'is_rider': False,
        'is_admin': False,
    }

    if RoleTypes.SELLER.value in user_roles:
        claims['is_seller']=True
    if RoleTypes.RIDER.value in user_roles:
        claims['is_rider']=True
    if RoleTypes.ADMIN.value in user_roles:
        claims['is_rider']=False
        claims['is_seller']=False
        claims['is_admin']=True

    access_token = create_access_token(identity=username, additional_claims=claims)
    response = jsonify(msg="Successfully logged in!", access_token=access_token)
    set_access_cookies(response, access_token)

    return response

@auth_bp.post('/logout')
@jwt_required()
def logout():
    response=jsonify(msg="Successfully logged out!") 
    unset_jwt_cookies(response)

    return response

@auth_bp.post('/register')
def register():
    if not request.is_json:
        abort(400)
    
    data=request.get_json()

    try:
        user=User(email=data['email'], username=data['username'])
        user.set_password(data['password'])

        role=db.session.execute(select(Role).where(Role.id==RoleTypes.BUYER.value)).scalar_one_or_none()
        user_role=UserRole(user, role)

        db.session.add(user)
        db.session.add(user_role)
        db.session.commit()

        return jsonify(msg="Successfully registered user!"), 201
    except IntegrityError:
        db.session.rollback()
        return jsonify(msg="Email already exists!"), 400
    except:
        db.session.rollback()
        return jsonify(msg="An error occurred!"), 500
    
@auth_bp.get('/protected')
@jwt_required()
def protected():
    user=db.session.execute(select(User).where(User.id==current_user.id)).scalar_one_or_none()
    return jsonify(user_id=user.id), 200
