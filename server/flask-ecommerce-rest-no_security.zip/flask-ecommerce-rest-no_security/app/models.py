import datetime
import enum
from typing import List

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    registry,
    mapped_column,
    relationship
)
from sqlalchemy import (
    ForeignKey,
    DATETIME,
    String,
    BIGINT,
    TEXT,
    VARCHAR,
    Column,
    Table,
    Enum,
    select
)
from dataclasses import dataclass
from flask_bcrypt import generate_password_hash, check_password_hash

class RoleTypes(enum.Enum):
    ADMIN=1
    SELLER=2
    RIDER=3
    BUYER=4

class StoreRequestStatus(enum.Enum):
    ACCEPTED=1
    REJECTED=2
    PENDING=3

mapper_registry = registry(
    type_annotation_map = {
        str: String()
        .with_variant(VARCHAR(255), "mysql"),
    }
)

class Base(DeclarativeBase):
    registry=mapper_registry

db=SQLAlchemy(model_class=Base)

@dataclass
class User(Base):
    __tablename__='user'

    id: Mapped[int] = mapped_column(BIGINT, primary_key=True)
    email: Mapped[str] = mapped_column(unique=True)
    password_hash: Mapped[str]
    username: Mapped[str] = mapped_column(unique=True)
    active: Mapped[bool] = mapped_column(default=True)
    email_verified: Mapped[bool] = mapped_column(default=False)
    created_at: Mapped[datetime.datetime] = mapped_column(default=lambda: datetime.datetime.now())
    updated_at: Mapped[datetime.datetime] = mapped_column(nullable=True, onupdate=lambda: datetime.datetime.now())

    roles: Mapped[List["UserRole"]] = relationship(back_populates='user', cascade='all, delete')
    seller: Mapped["Seller"] = relationship(back_populates='user', cascade='all, delete')
    registration: Mapped["StoreRegistration"] = relationship(back_populates='user', cascade='all, delete')
    store: Mapped["Store"] = relationship(back_populates='user', cascade='all, delete')

    def set_password(self, password):
        self.password_hash=generate_password_hash(password).decode('utf-8')

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def isActive(self):
        return self.active
    
    def isVerified(self):
        return self.email_verified
    
    def setActive(self, activation: bool):
        self.active = activation
    
    def setVerification(self, verification: bool):
        self.email_verified = verification

    def to_json(self):
        return {
            "Username": self.username,
            "User email": self.email,
            "User active": self.active
        }

class Role(Base):
    __tablename__='role'

    id: Mapped[int] = mapped_column(BIGINT, primary_key=True)
    name: Mapped[str]

@dataclass
class UserRole(Base):
    __tablename__='user_roles'

    user_id: Mapped[int] = mapped_column(ForeignKey('user.id', ondelete='CASCADE'), primary_key=True)
    role_id: Mapped[int] = mapped_column(ForeignKey('role.id', ondelete='CASCADE'), primary_key=True)
    assigned_at: Mapped[datetime.datetime] = mapped_column(default=lambda: datetime.datetime.now())

    user: Mapped["User"] = relationship(back_populates='roles')
    role: Mapped["Role"] = relationship()

    def __init__(self, user, role):
        self.user=user
        self.role=role

@dataclass
class Seller(Base):
    __tablename__='seller_profiles'

    id: Mapped[int] = mapped_column(BIGINT, primary_key=True)
    full_name: Mapped[str]
    residential_address: Mapped[str]
    personal_phone_number: Mapped[str]
    country: Mapped[str]
    province: Mapped[str]
    city: Mapped[str]
    # government ID here
    created_at: Mapped[datetime.datetime] = mapped_column(default=lambda: datetime.datetime.now())
    updated_at: Mapped[datetime.datetime] = mapped_column(nullable=True, onupdate=lambda: datetime.datetime.now())
    
    user_id: Mapped[int] = mapped_column(ForeignKey('user.id', ondelete='CASCADE'), unique=True)

    user: Mapped["User"] = relationship(back_populates='seller', cascade='all, delete')
    registration: Mapped["StoreRegistration"] = relationship(back_populates='seller', cascade='all, delete')
    store: Mapped["Store"] = relationship(back_populates='seller', cascade='all, delete')

class Store(Base):
    __tablename__='stores'

    id: Mapped[int] = mapped_column(BIGINT, primary_key=True)
    store_name: Mapped[str]
    store_email: Mapped[str] = mapped_column(unique=True)
    description: Mapped[str] = mapped_column(TEXT)
    country: Mapped[str]
    address: Mapped[str]
    store_phone_number: Mapped[str]
    created_at: Mapped[datetime.datetime] = mapped_column(default=lambda: datetime.datetime.now())
    updated_at: Mapped[datetime.datetime] = mapped_column(nullable=True)
    
    user_id: Mapped[int] = mapped_column(ForeignKey('user.id', ondelete='CASCADE'), unique=True)
    seller_id: Mapped[int] = mapped_column(ForeignKey('seller_profiles.id', ondelete='CASCADE'))

    user: Mapped["User"] = relationship(back_populates='store', cascade='all, delete')
    seller: Mapped["Seller"] = relationship(back_populates='store', cascade='all, delete')
    products: Mapped[List["Product"]] = relationship(cascade='all, delete')

    def isAccepted(self) -> bool:
        return self.seller.registration.request_status.name==StoreRequestStatus.ACCEPTED.name

@dataclass
class StoreRegistration(Base):
    __tablename__='store_registrations'

    id: Mapped[int] = mapped_column(BIGINT, primary_key=True)
    request_status: Mapped[StoreRequestStatus] = mapped_column(default=StoreRequestStatus.PENDING.name)
    store_purpose: Mapped[str] = mapped_column(TEXT)
    created_at: Mapped[datetime.datetime] = mapped_column(default=lambda: datetime.datetime.now())
    updated_at: Mapped[datetime.datetime] = mapped_column(nullable=True, onupdate=lambda: datetime.datetime.now())
    # reason for decline / message

    user_id: Mapped[int] = mapped_column(ForeignKey('user.id', ondelete='CASCADE'), unique=True)
    seller_id: Mapped[int] = mapped_column(ForeignKey('seller_profiles.id', ondelete='CASCADE'))

    user: Mapped["User"] = relationship(back_populates='registration', cascade='all, delete')
    seller: Mapped["Seller"] = relationship(back_populates='registration', cascade='all, delete')

    def to_json(self):
        return {
            'Seller full name': self.seller.full_name,
            'Seller email': self.seller.user.email,
            'Store purpose': self.store_purpose,
            'Request status': self.request_status.name,
            'Request date created': self.created_at,
            'Request date updated': self.updated_at
        }
    
    def acceptStoreRegistration(self):
        self.request_status=StoreRequestStatus.ACCEPTED
    
    def rejectStoreRegistration(self):
        self.request_status=StoreRequestStatus.REJECTED

@dataclass
class Product(Base):
    __tablename__='products'

    id: Mapped[int] = mapped_column(BIGINT, primary_key=True)
    name: Mapped[str]
    price: Mapped[int]
    quantity: Mapped[int]
    description: Mapped[str] = mapped_column(TEXT, nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(default=lambda: datetime.datetime.now())
    updated_at: Mapped[datetime.datetime] = mapped_column(nullable=True, onupdate=lambda: datetime.datetime.now())

    store_id: Mapped[int] = mapped_column(ForeignKey("stores.id", ondelete="CASCADE"))

    categories: Mapped[List["ProductCategory"]] = relationship(cascade='all, delete')


class Category(Base):
    __tablename__='categories'

    id: Mapped[int] = mapped_column(BIGINT, primary_key=True)
    name: Mapped[str]

class ProductCategory(Base):
    __tablename__='product_categories'

    product_id: Mapped[int] = mapped_column(ForeignKey('products.id', ondelete='CASCADE'), primary_key=True)
    category_id: Mapped[int] = mapped_column(ForeignKey('categories.id', ondelete='CASCADE'), primary_key=True)

    product: Mapped["Product"] = relationship(back_populates='categories', cascade='all, delete')
    category: Mapped["Category"] = relationship()

