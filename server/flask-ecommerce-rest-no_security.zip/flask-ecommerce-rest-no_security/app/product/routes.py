import datetime

from . import (
    products as products_bp,
    db,
    Product,
    Store,
    seller_required,
    is_store_accepted
)
from flask import (
    jsonify,
    abort,
    request
)
from flask_jwt_extended import (
    jwt_required,
    current_user
)
from sqlalchemy import select

@products_bp.get('/product/<int:product_id>')
def getProduct(product_id):
    product=db.session.execute(select(Product).where(Product.id==product_id)).scalar_one_or_none()

    try:
        return jsonify(product=product)
    except:
        return jsonify(msg="Error occurred!"), 500

@products_bp.get('/product/<string:product_name>')
def getProductByName(product_name):
    product_name_input = request.args.get(product_name)
    products=db.session.execute(select(Product).where(Product.name.ilike(f'%{product_name_input}%'))).scalars().all()

    try:
        return jsonify(products=products)
    except:
        return jsonify(msg="Error occurred!"), 500

@products_bp.post('/create')
@jwt_required()
@seller_required()
@is_store_accepted
def createProduct():
    if not request.is_json:
        abort(400)

    store=db.session.execute(select(Store).where(Store.user_id==current_user.id)).scalar_one_or_none()

    try:
        data = request.get_json()

        product=Product(
            name=data['name'],
            price=data['price'],
            quantity=data['quantity'],
            description=data['description'],
            store_id=store.id
        )

        db.session.add(product)
        db.session.commit()

        return jsonify(msg="Succesfully created product!"), 201
    except:
        db.session.rollback()
        return jsonify(msg="Error occurred!"), 500
    
@products_bp.delete('/delete/<int:product_id>')
@jwt_required()
@seller_required()
@is_store_accepted
def deleteProduct(product_id):
    product=db.session.execute(select(Product).where(Product.id==product_id)).scalar_one_or_none()
    store=db.session.execute(select(Store).where(Store.user_id==current_user.id)).scalar_one_or_none()
    
    try:
        if product.store_id!=store.id:
            return jsonify(msg="Unauthorized request!"), 403
        
        db.session.delete(product)
        db.session.commit()

        return jsonify(msg="Successfully deleted product!"), 200
    except:
        db.session.rollback()
        return jsonify(msg="Error occurred!"), 500
    
@products_bp.put('/edit/<int:product_id>')
@jwt_required()
@seller_required()
@is_store_accepted
def updateProduct(product_id):
    if not request.is_json:
        abort(400)
    
    product=db.session.execute(select(Product).where(Product.id==product_id)).scalar_one_or_none()
    store=db.session.execute(select(Store).where(Store.user_id==current_user.id)).scalar_one_or_none()

    try:
        if product.store_id!=store.id:
            return jsonify(msg="Unauthorized request!"), 403
        
        data = request.get_json()

        if not (data['name'] == ''):
            product.name=data['name']
        if data['price'] is not None:
            product.price=data['price']
        if data['quantity'] is not None:
            product.quantity=data['quantity']
        if not (data['description'] == ''):
            product.description=data['description']

        product.updated_at=datetime.datetime.now()

        db.session.commit()

        return jsonify(msg="Succesfully updated product!"), 201
    except:
        db.session.rollback()
        return jsonify(msg="Error occurred!"), 500