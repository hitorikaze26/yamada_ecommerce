from . import (
    cart as cart_bp,
    db
)
from flask import (
    jsonify,
    abort
)
from flask_jwt_extended import (
    jwt_required,
    current_user
)

@cart_bp.get('/get-cart')
@jwt_required()
def getCart():
    return jsonify(msg='TRUE'), 200

@cart_bp.post('/add-to-cart')
@jwt_required()
def addToCart():
    return True