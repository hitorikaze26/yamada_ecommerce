from . import (
    seller as seller_bp,
    db,
    User,
    UserRole,
    Role,
    RoleTypes,
    Product,
    Seller,
    StoreRegistration
)
from flask import (
    jsonify,
    abort,
    request
)
from app.decorators import (
    seller_required
)
from flask_jwt_extended import (
    jwt_required,
    current_user
)
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

@seller_bp.post('/create-profile')
@jwt_required()
def createSellerProfile():
    if not request.is_json:
        abort(400)

    try:
        data = request.get_json()
        
        seller=Seller(
            full_name=data['full_name'],
            residential_address=data['residential_address'],
            personal_phone_number=data['personal_phone_number'],
            country=data['country'],
            province=data['province'],
            city=data['city'],
            user_id=current_user.id
        )

        user=db.session.execute(select(User).where(User.id==current_user.id)).scalar_one_or_none()
        role=db.session.execute(select(Role).where(Role.id==RoleTypes.SELLER.value)).scalar_one_or_none()
        user.roles.append(UserRole(user, role))

        db.session.add(seller)
        db.session.add(user)
        db.session.commit()

        return jsonify(msg='Successfully created seller profile!'), 201
    except IntegrityError:
        db.session.rollback()
        return jsonify(msg='Seller profile already exists!'), 400
    except:
        db.session.rollback()
        return jsonify(msg='Error occurred!'), 500

@seller_bp.get('/profile')
@jwt_required()
@seller_required()
def getSellerProfile():
    seller=db.session.execute(select(Seller).where(Seller.user_id==current_user.id)).scalar_one_or_none()

    if seller is None:
        seller_profile=None
    else:
        seller_profile = {
            'full_name': seller.full_name,
            'email': seller.user.email,
            'residential_address': seller.residential_address,
            'personal_phone_number': seller.personal_phone_number,
            'country': seller.country,
            'province': seller.province,
            'city': seller.city,
        }

    try:
        return jsonify(seller_profile=seller_profile), 200
    except:
        db.session.rollback()
        return jsonify(msg='Error occurred!'), 500