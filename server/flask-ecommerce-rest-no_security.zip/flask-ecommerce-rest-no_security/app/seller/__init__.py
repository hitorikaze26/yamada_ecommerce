from flask import Blueprint
from app.models import (
    db, 
    Product,
    Seller,
    StoreRegistration,
    User,
    UserRole,
    Role,
    RoleTypes,
)

seller=Blueprint('seller', __name__)

from . import routes